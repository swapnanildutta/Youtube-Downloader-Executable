# -*- coding: utf-8 -*-
"""Package init | pydocstyle ignore isn't working :/."""
